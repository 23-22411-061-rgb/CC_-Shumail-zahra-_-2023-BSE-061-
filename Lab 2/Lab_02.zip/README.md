# LAB 02 Package

This package contains the following:

1. **LAB_02.pdf** - The PDF version of the provided Word document.
2. **screenshots/** - A folder containing all images from the document in order, named step_1.png, step_2.png, etc.
3. **README.md** - This file, explaining the contents.

The order of images matches the order in which they appeared in the original Word document.
