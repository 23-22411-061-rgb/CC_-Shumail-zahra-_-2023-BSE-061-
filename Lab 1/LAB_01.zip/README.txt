README - LAB 01 Package

This ZIP contains the following:
1. LAB_01.pdf - The converted document in PDF format.
2. screenshots/ - Folder with all images extracted from the document.
   Images are labeled step_1.png to step_N.png, in order.
3. README.txt - This file describing the contents.

Order of files follows the sequence in the document.